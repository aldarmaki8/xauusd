import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
export async function GET(){ const plans = await prisma.plan.findMany({ where:{active:true}, orderBy:{months:'asc'} }); const walletNetwork=process.env.WALLET_NETWORK||'USDT (TRC20)'; const walletAddress=process.env.WALLET_ADDRESS||'TUFXDVZQUcCGe6WS3NEVuCxHXtTwZ7pU28'; return NextResponse.json({ plans, walletNetwork, walletAddress }); }
