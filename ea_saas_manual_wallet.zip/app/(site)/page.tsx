"use client";
import { useEffect, useState } from "react";
import Brand from "@/components/Brand";

type Plan = { id?: string; slug: string; name: string; months: number; priceCents: number };

export default function Home(){
  const [email, setEmail] = useState(""); 
  const [accountMT5, setAccount] = useState(""); 
  const [planSlug, setPlanSlug] = useState("monthly");
  const [plans, setPlans] = useState<Plan[]>([]);
  const [wallet, setWallet] = useState({ network: "", address: "" });

  useEffect(()=>{
    fetch("/api/public/config").then(r=>r.json()).then(cfg=>{
      setPlans(cfg.plans);
      setWallet({ network: cfg.walletNetwork, address: cfg.walletAddress });
    });
  },[]);

  return (
    <main className="min-h-screen py-12">
      <div className="container space-y-10">
        <div className="flex items-center justify-between">
          <Brand/>
          <a className="btn-outline" href="/pay">صفحة الدفع</a>
        </div>

        <section className="grid md:grid-cols-2 gap-8 items-start">
          <div className="space-y-6">
            <h1 className="text-4xl md:text-5xl font-black leading-tight">
              اشترك في الاكسبيرت <span className="text-gold">(MT5)</span> — الدفع اليدوي
            </h1>
            <p className="text-white/70">
              قم بالتحويل على عنوان المحفظة ثم أرسل لنا إثبات الدفع (TxID) وسنفعّل الاشتراك يدويًا.
            </p>

            <div className="card p-6 space-y-4">
              <div className="grid gap-3 md:grid-cols-2">
                <input className="input" placeholder="البريد الإلكتروني" value={email} onChange={e=>setEmail(e.target.value)}/>
                <input className="input" placeholder="رقم حساب MT5" value={accountMT5} onChange={e=>setAccount(e.target.value)}/>
              </div>
              <select className="input" value={planSlug} onChange={e=>setPlanSlug(e.target.value)}>
                {plans.map(p=> <option key={p.slug} value={p.slug}>{p.name} — ${ (p.priceCents/100).toFixed(0) }</option>)}
              </select>

              <div className="rounded-xl border border-white/10 p-4 bg-white/5">
                <div className="text-white/60 text-sm">شبكة التحويل</div>
                <div className="font-semibold">{wallet.network || "USDT (TRC20)"}</div>
                <div className="mt-3 text-white/60 text-sm">عنوان المحفظة</div>
                <div className="flex items-center gap-3 overflow-x-auto">
                  <code className="kbd">{wallet.address || "T..."}</code>
                  <button className="btn-outline" onClick={()=>navigator.clipboard.writeText(wallet.address)}>نسخ</button>
                </div>
              </div>

              <a href={`/proof?plan=${planSlug}&email=${encodeURIComponent(email)}&account=${encodeURIComponent(accountMT5)}`} className="btn">أرسل إثبات الدفع</a>
            </div>
          </div>

          <div className="card p-6">
            <h3 className="font-bold mb-3">كيف يتم التفعيل؟</h3>
            <ol className="list-decimal list-inside space-y-2 text-white/80">
              <li>اختر الباقة وأرسل المبلغ على عنوان المحفظة.</li>
              <li>اضغط "أرسل إثبات الدفع" واملأ البيانات.</li>
              <li>نراجع الطلب ونفعّل الاشتراك يدويًا.</li>
            </ol>
          </div>
        </section>
      </div>
    </main>
  );
}
