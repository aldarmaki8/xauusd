import { prisma } from "@/lib/db";

export default async function WalletInfo(){
  const walletNetwork = process.env.WALLET_NETWORK || "USDT (TRC20)";
  const walletAddress = process.env.WALLET_ADDRESS || "TUFXDVZQUcCGe6WS3NEVuCxHXtTwZ7pU28";
  const plans = await prisma.plan.findMany({ where: { active: true }, orderBy: { months: "asc" } });
  return (
    <div className="card p-6 space-y-4">
      <div className="text-white/60">شبكة</div>
      <div className="font-semibold">{walletNetwork}</div>
      <div className="text-white/60">العنوان</div>
      <div className="flex items-center gap-3 overflow-x-auto">
        <code className="kbd">{walletAddress}</code>
      </div>
      <div className="mt-4">
        <div className="text-white/60 mb-2">الخطط</div>
        <ul className="space-y-2">
          {plans.map(p => (
            <li key={p.id} className="flex items-center justify-between bg-white/5 rounded-xl p-3">
              <span>{p.name}</span>
              <span className="text-white/70">${(p.priceCents/100).toFixed(0)}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
