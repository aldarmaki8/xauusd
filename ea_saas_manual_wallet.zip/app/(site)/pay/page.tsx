import WalletInfo from './wallet';
export default function PayPage(){return (<main className='min-h-screen py-16'><div className='container space-y-6'><h1 className='text-3xl font-black'>صفحة الدفع اليدوي</h1><WalletInfo/></div></main>)}
