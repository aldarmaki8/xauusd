"use client";
import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";

export default function Proof(){
  const sp = useSearchParams();
  const [email,setEmail] = useState(sp.get("email")||"");
  const [account,setAccount] = useState(sp.get("account")||"");
  const [plan,setPlan] = useState(sp.get("plan")||"monthly");
  const [txid,setTxid] = useState("");
  const [amount,setAmount] = useState<string>("");
  const [note,setNote] = useState("");
  const [plans,setPlans] = useState<any[]>([]);
  const [done,setDone] = useState(false);
  const [error,setError] = useState<string|null>(null);

  useEffect(()=>{ fetch("/api/public/config").then(r=>r.json()).then(cfg=>setPlans(cfg.plans)); },[]);

  async function submit(){
    setError(null);
    const res = await fetch("/api/proof/submit", {
      method: "POST",
      headers: { "content-type":"application/json" },
      body: JSON.stringify({ email, accountMT5: account, planSlug: plan, txid, amountCents: amount? Math.round(parseFloat(amount)*100) : null, note })
    });
    const data = await res.json();
    if(!res.ok){ setError(data.error||"error"); return; }
    setDone(true);
  }

  if(done){
    return (
      <main className="min-h-screen grid place-items-center">
        <div className="card p-10 text-center space-y-3">
          <h2 className="text-2xl font-black">تم الإرسال ✅</h2>
          <p className="text-white/70">سنراجع الطلب ونفعّل الاشتراك يدويًا خلال وقت قصير.</p>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen grid place-items-center">
      <div className="card p-8 w-full max-w-2xl space-y-4">
        <h1 className="text-xl font-bold">إرسال إثبات الدفع</h1>
        {error && <div className="text-red-400 text-sm">{error}</div>}
        <div className="grid md:grid-cols-2 gap-3">
          <input className="input" placeholder="البريد" value={email} onChange={e=>setEmail(e.target.value)}/>
          <input className="input" placeholder="رقم حساب MT5" value={account} onChange={e=>setAccount(e.target.value)}/>
        </div>
        <div className="grid md:grid-cols-2 gap-3">
          <select className="input" value={plan} onChange={e=>setPlan(e.target.value)}>
            {plans.map((p:any)=> <option key={p.slug} value={p.slug}>{p.name}</option>)}
          </select>
          <input className="input" placeholder="المبلغ (اختياري)" value={amount} onChange={e=>setAmount(e.target.value)}/>
        </div>
        <input className="input" placeholder="TxID / Hash" value={txid} onChange={e=>setTxid(e.target.value)}/>
        <textarea className="input" placeholder="ملاحظات (اختياري)" value={note} onChange={e=>setNote(e.target.value)} rows={4}/>
        <button className="btn" onClick={submit}>إرسال</button>
      </div>
    </main>
  )
}
