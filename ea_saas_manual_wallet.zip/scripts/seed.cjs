const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
(async()=>{try{const raw=process.env.DEFAULT_PRICES_JSON||'[]';const items=JSON.parse(raw);for(const p of items){await prisma.plan.upsert({where:{slug:p.slug},update:{name:p.name,months:p.months,priceCents:p.priceCents,active:true},create:{slug:p.slug,name:p.name,months:p.months,priceCents:p.priceCents,active:true}});}console.log('Seeded',items.length,'plans.');}catch(e){console.error(e);process.exit(1);}finally{await prisma.$disconnect();}})();
